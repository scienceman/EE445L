void Draw_Clock(void);

extern unsigned char imageBuff[];
extern unsigned char clock1[];

void DisplayTimeNumeric(int hour, int min, int sec);
void DisplayTimeClock(int hour, int min, int sec);
void DisplayAlarmNumeric(int hour, int min);
