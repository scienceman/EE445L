extern int displayClock;

void Switch_Init(void);

void toggleDisplay(void);

void EdgeCounter_Init(void);

void GPIOPortG_Handler(void);

void GPIOPortC_Handler(void);
