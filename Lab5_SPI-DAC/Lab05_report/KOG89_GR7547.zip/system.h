// System functions LM3S1968 header file

void System_Init(void);
void Switch_Init(void);
void SSI_Init(void);
void DAC_Out(unsigned short);
void debugGPIO(void);
