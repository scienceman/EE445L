void Switch_Init(void);
