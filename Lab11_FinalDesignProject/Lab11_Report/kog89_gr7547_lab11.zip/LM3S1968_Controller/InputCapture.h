void TimerCapture_Init(void);
