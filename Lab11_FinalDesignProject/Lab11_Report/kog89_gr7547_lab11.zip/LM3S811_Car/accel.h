void Accel_Init(unsigned long periph_base_y, unsigned long base_y, unsigned long pin_y, 
					unsigned long periph_base_x, unsigned long base_x, unsigned long pin_x);
int* Accel_Recieve(void);
