// System functions LM3S1968 header file

void System_Init(void);
void motorIO_811_Init(void);
void motorIO_1968_Init(void);
void Switch_Init(void);
void PeriodMeasure_Init(void);
void Timer0A_Handler(void);
